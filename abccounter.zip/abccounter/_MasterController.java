package edu.citytech.cst.s23420931.abccounter;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.MenuBar;
import javafx.stage.Stage;

import java.io.IOException;

public class _MasterController {
    @FXML
    private MenuBar menuBar;
    public void getFXML(Stage stage, String title, String location) {

        stage.setTitle(title);
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(location));
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    protected void itemABC(ActionEvent event) throws IOException {
        System.out.println("item abc was selected");

        Stage stage = (Stage) menuBar.getScene().getWindow();
        getFXML(stage, "title one", "/fxml/ABCCounterView.fxml");
    }

    @FXML
    protected void itemFinalGrade(ActionEvent event) throws IOException {
        System.out.println("item finalGrade was selected");
        Stage stage = (Stage) menuBar.getScene().getWindow();
        getFXML(stage, "title two", "/fxml/FinalGradeView2.fxml");
    }
    @FXML
    protected void itemCustomer(ActionEvent event) throws IOException {
        System.out.println("item CustomerPurchases was selected");
        Stage stage = (Stage) menuBar.getScene().getWindow();
        getFXML(stage, "title three", "/fxml/CustomerPrucahseViewOther.fxml");
    }
    @FXML
    protected void itemPurchases(ActionEvent event) throws IOException {
        System.out.println("item Purchases was selected");
        Stage stage = (Stage) menuBar.getScene().getWindow();
        getFXML(stage, "title four", "/fxml/PurchasesView.fxml");
    }
        @FXML
        protected void isFinalProject(ActionEvent event) throws IOException {
            System.out.println("item abc was selected");

            Stage stage = (Stage) menuBar.getScene().getWindow();
            getFXML(stage, "title one", "/fxml/FinalProjectView.fxml");
        }
    }

