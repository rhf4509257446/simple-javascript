package edu.citytech.cst.s23420931.abccounter;

import com.jbbwebsolutions.http.utility.JSONGet;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.FlowPane;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;


public class ABCCounterCotroll extends _MasterController implements Initializable {

    @FXML
    private Label title;
    @FXML
    private FlowPane fpCounter;
    @FXML
    private RadioButton rbabc;
    @FXML
    private RadioButton rbcba;
    @FXML
    private RadioButton rbaa;
    @FXML
    private RadioButton rb123;
    @FXML
    private RadioButton rb321;
    @FXML
    private RadioButton rb369;
    @FXML
    private RadioButton rbNone;
    @FXML
    private Label Highlight;
    @FXML
    private ChoiceBox<String> cbIsVowel;

    @FXML
    void modeNone(ActionEvent event) {
        fpCounter.getChildren().clear();
        cbIsVowel.getItems().clear();
        Highlight.setText("");
        title.setText("ABC,123 Count");
    }
    @FXML
    void mode123(ActionEvent event) {
        cbIsVowel.getItems().clear();
        cbIsVowel.getItems().add("none");
        cbIsVowel.getItems().add("even");
        cbIsVowel.getItems().add("odd");
        cbIsVowel.getItems().add("every.6");
        cbIsVowel.getItems().add("Contains7");
        fpCounter.getChildren().clear();
        Highlight.setText("");
        title.setText("123 Mode");

        Integer[] list= JSONGet.submitGet("http://localhost:8080/api/abc/123", Integer[].class);

        for (int abc : list) {
            var label = new Label(abc + "");
            label.getStyleClass().add("displayLabel-123");
            fpCounter.getChildren().add(label);
        }
    }

    @FXML
    void mode(ActionEvent event) {
        cbIsVowel.getItems().clear();
        cbIsVowel.getItems().add("none");
        cbIsVowel.getItems().add("vowels");
        cbIsVowel.getItems().add("consonant");
        fpCounter.getChildren().clear();
        Highlight.setText("");
        title.setText("ABC Mode");

        //List<Character> list = ABCCounterService.countABC();
        Character[] list= JSONGet.submitGet("http://localhost:8080/api/abc/abc", Character[].class);
        for (char abc : list) {
            var label = new Label(abc + "");
            label.getStyleClass().add("displayLabel-big");
            fpCounter.getChildren().add(label);
        }
    }
    @FXML
    void modeAa(ActionEvent event) {
        cbIsVowel.getItems().clear();
        cbIsVowel.getItems().add("none");
        cbIsVowel.getItems().add("Vowels");
        cbIsVowel.getItems().add("Consonant");
        fpCounter.getChildren().clear();
        Highlight.setText("");
        title.setText("A-a Mode");

        List<Character> list = ABCCounterService.countAa();
        for (char ABC : list) {
            var label = new Label(ABC +"-" + Character.toLowerCase(ABC));
            label.getStyleClass().add("displayLabel-Aa");
            fpCounter.getChildren().add(label);
        }
    }
    @FXML
    void mode321(ActionEvent event) {
        cbIsVowel.getItems().clear();
        cbIsVowel.getItems().add("none");
        cbIsVowel.getItems().add("even");
        cbIsVowel.getItems().add("odd");
        cbIsVowel.getItems().add("Contains7");
        fpCounter.getChildren().clear();
        Highlight.setText("");
        title.setText("321 Mode");
        List<Integer> list = ABCCounterService.count321();
        for (int abc : list) {
            var label = new Label(abc + "");
            label.getStyleClass().add("displayLabel-123");
            fpCounter.getChildren().add(label);

        }
    }
    @FXML
    void modecba(ActionEvent event) {
        cbIsVowel.getItems().clear();
        cbIsVowel.getItems().add("none");
        cbIsVowel.getItems().add("vowels");
        cbIsVowel.getItems().add("consonant");
        fpCounter.getChildren().clear();
        title.setText("CBA Mode");
        Highlight.setText("");

        List<Character> list = ABCCounterService.countCBA();
        for (char abc : list) {
            var label = new Label(abc + "");
            label.getStyleClass().add("displayLabel-big");
            fpCounter.getChildren().add(label);
        }
    }
    @FXML
    void mode369(ActionEvent event) {
        cbIsVowel.getItems().clear();
        cbIsVowel.getItems().add("none");
        cbIsVowel.getItems().add("even");
        cbIsVowel.getItems().add("odd");
        cbIsVowel.getItems().add("Contains7");
        fpCounter.getChildren().clear();
        Highlight.setText("");
        title.setText("369 Mode");
        List<Integer> list = ABCCounterService.count369();
        for (int abc : list) {
            var label = new Label(abc + "");
            label.getStyleClass().add("displayLabel-123");
            fpCounter.getChildren().add(label);

        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        fpCounter.getChildren().clear();

        cbIsVowel.getItems().add("none");
        cbIsVowel.getItems().add("vowels");
        cbIsVowel.getItems().add("consonant");

        cbIsVowel.setOnAction(this::selectMode);
    }

    public void selectMode(ActionEvent e) {
        String selectedItem = cbIsVowel.getSelectionModel().getSelectedItem();
        var labels = fpCounter.getChildren();

        if (selectedItem != null && selectedItem.contains("vowel")) {
            for (Node currentLabel : labels) {
                Label realLabel = (Label) currentLabel;
                realLabel.getStyleClass().clear();
                realLabel.getStyleClass().add("displayLabel-big");
                boolean isVowel = ABCCounterService.isVowel(realLabel.getText());
                if (isVowel)
                    currentLabel.getStyleClass().add("isVowel");
                }

        } else  if (selectedItem != null && selectedItem.contains("Vowel")) {
                for (Node currentLabel : labels) {
                    Label realLabel = (Label) currentLabel;
                    realLabel.getStyleClass().clear();
                    realLabel.getStyleClass().add("displayLabel-Aa");
                    boolean isVowel = ABCCounterService.isVowel(realLabel.getText());
                    if (isVowel)
                        currentLabel.getStyleClass().add("isVowel");
                }
        } else if (selectedItem != null && selectedItem.contains("consonant")) {
            for (Node currentLabel : labels) {
                Label realLabel = (Label) currentLabel;
                realLabel.getStyleClass().clear();
                realLabel.getStyleClass().add("displayLabel-big");
                boolean isVowel = ABCCounterService.isConsonant(realLabel.getText());
                if (isVowel)
                    currentLabel.getStyleClass().add("isConsonant");
            }
        } else if (selectedItem != null && selectedItem.contains("Consonant")) {
            for (Node currentLabel : labels) {
                Label realLabel = (Label) currentLabel;
                realLabel.getStyleClass().clear();
                realLabel.getStyleClass().add("displayLabel-Aa");
                boolean isVowel = ABCCounterService.isConsonant(realLabel.getText());
                if (isVowel)
                    currentLabel.getStyleClass().add("isConsonant");
            }
        } else if (selectedItem != null && selectedItem.contains("even")) {
            for (Node currentLabel : labels) {
                Label realLabel = (Label) currentLabel;
                realLabel.getStyleClass().clear();
                realLabel.getStyleClass().add("displayLabel-123");
                int no = Integer.parseInt(realLabel.getText());
                boolean isVowel = ABCCounterService.isEven(no);
                if (isVowel)
                    currentLabel.getStyleClass().add("isEven");
            }
        }
        else if (selectedItem != null && selectedItem.contains("odd")) {
            for (Node currentLabel : labels) {
                Label realLabel = (Label) currentLabel;
                realLabel.getStyleClass().clear();
                realLabel.getStyleClass().add("displayLabel-123");
                int one = Integer.parseInt(realLabel.getText());
                boolean isVowel = ABCCounterService.isOdd(one);
                if (isVowel)
                    currentLabel.getStyleClass().add("isOdd");
            }
        }
        else if (selectedItem != null && selectedItem.contains("none")) {
            for (Node currentLabel : labels) {
                Label realLabel = (Label) currentLabel;
                currentLabel.getStyleClass().remove("isEven");
                currentLabel.getStyleClass().remove("isOdd");
                currentLabel.getStyleClass().remove("isVowel");
                currentLabel.getStyleClass().remove("isConsonant");
            }
        }
        else if (selectedItem != null && selectedItem.contains("every.6")) {
            for (Node currentLabel : labels) {
                Label realLabel = (Label) currentLabel;
                realLabel.getStyleClass().clear();
                realLabel.getStyleClass().add("displayLabel-123");
                int one = Integer.parseInt(realLabel.getText());
                boolean isVowel = ABCCounterService.isSix(one);
                if (isVowel)
                    currentLabel.getStyleClass().add("isSix");
            }
        }
        else if (selectedItem != null && selectedItem.contains("Contains7")) {
            for (Node currentLabel : labels) {
                Label realLabel = (Label) currentLabel;
                realLabel.getStyleClass().clear();
                realLabel.getStyleClass().add("displayLabel-123");
                int one = Integer.parseInt(realLabel.getText());

                boolean isVowel = ABCCounterService.isContains7(one);
                if (isVowel)
                    currentLabel.getStyleClass().add("isSix");

            }
        }
    }
}