package edu.citytech.cst.s23420931.CustomerPurchase2;
import edu.citytech.cst.s23420931.abccounter._MasterController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class CustomerPurchaseMain1 extends Application{

    public static void main(String[] args) {
        Application.launch(args);
    }
    @Override
    public void start(Stage stage) throws Exception {
        new _MasterController().getFXML(stage,"title four",
                "/fxml/PurchasesView.fxml");
    }
}

