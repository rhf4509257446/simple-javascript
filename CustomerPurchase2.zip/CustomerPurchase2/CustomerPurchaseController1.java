package edu.citytech.cst.s23420931.CustomerPurchase2;

import com.jbbwebsolutions.http.utility.JSONGet;
import com.jbbwebsolutions.http.utility.URLUtility;
import edu.citytech.cst.s23420931.Model1.Items;
import edu.citytech.cst.s23420931.Model1.ClientInfo;
import edu.citytech.cst.s23420931.abccounter._MasterController;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.util.*;

public class CustomerPurchaseController1 extends _MasterController implements Initializable {

    @FXML
    private TableView<Items> tvCustomerPurchase1;

    @FXML
    private Label DataID;

    @FXML
    private Label Price;

    @FXML
    private Button btSearch2;
    @FXML
    private Label lplmessage;

    @FXML
    private TextField idNumber;
    @FXML
    private Label rewarddetail;
    @FXML
    private Label previewdetail;

    @FXML
    private Label taxpaiddetail;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }


    public void search(final String url) {
        lplmessage.setText("");
        ClientInfo data = JSONGet.submitGet(url, ClientInfo.class);
        ObservableList<Items> cp = tvCustomerPurchase1.getItems();
        if (data == null) {
            lplmessage.setText("no data found:" + idNumber.getText());
            return;
        }
        cp.addAll(data.getItems());
        DataID.setText("Data for Customer ID: " + data.getCustomerId());
        Price.setText("Total price is: " + data.getTotalPrice());

    }

        @FXML
        void search (ActionEvent event){
            final var sUrl = "http://localhost:3613/customer/api/query/:_id";

            tvCustomerPurchase1.refresh();

            tvCustomerPurchase1.getItems().clear();

            String id = idNumber.getText();
            var url = sUrl.replaceAll(":_id", id);
            search(url);
        }
    @FXML
    void updata(ActionEvent event) {
        String url = "http://localhost:3613/customer/api/update/rewards";
        String searchById = idNumber.getText();
        int id = Integer.parseInt((searchById));

        Map<String,Object> map = new HashMap<>();
        map.put("id",id);
        map.put("year",2020);
        map.put("day",4);
        map.put("month",16);
        var x = URLUtility.put(url,map,ClientInfo.class,3);


        rewarddetail.setText("reward: "+x.getRewards().getAmount());


    }
    @FXML
    void Preview(ActionEvent event) {
        String url = "http://localhost:3613/customer/api/preview/tax/:_id";
        String searchById = idNumber.getText();
        var surl = url.replaceAll(":_id", searchById);
        ClientInfo PaidDetail =JSONGet.submitGet(surl,ClientInfo.class);
        previewdetail.setText(""+PaidDetail.getTaxpaid().getAmount());


    }
    @FXML
    void taxpaid(ActionEvent event) {
        String url = "http://localhost:3613/customer/api/tax";
        String searchById = idNumber.getText();
        int id = Integer.parseInt((searchById));

        Map<String,Object> map = new HashMap<>();
        map.put("id",id);
        var t = URLUtility.put(url,map,ClientInfo.class,3);
        taxpaiddetail.setText(""+t.getTaxpaid().getAmount());

    }


}
