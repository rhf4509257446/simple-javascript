package edu.citytech.cst.s23420931.FinalGrade;


import edu.citytech.cst.s23420931.abccounter._MasterController;
import edu.citytech.cst.s23420931.service.GradeCalculator;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.util.Date;

public class FinalGradeController extends _MasterController {

    @FXML
    private Label title;

    @FXML
    private Label status;

    @FXML
    private TextField txtScore;

    @FXML
    private TextField txtGPA;

    @FXML
    private Button btnCalculate;
    @FXML
    private Button btnClear;
    @FXML
    private TextField txtStates;
    @FXML
    void Mainclear(ActionEvent event){
        txtScore.setText("");
        txtGPA.setText("0.0");
        status.setText("");
        txtStates.setText("");
    }

    @FXML
    void calculateGrade(ActionEvent event) {
        String sScore = txtScore.getText();
        if (!isNumber(sScore)) {
            status.setText("Invalid number was entered:" + sScore);
            return;
        }
        float score = Float.parseFloat(sScore);
        float gpa = GradeCalculator.getGPA(score);
        float grade =Float.parseFloat(sScore);
        String letter = GradeCalculator.letterGrade(grade);
        txtGPA.setText(gpa + "");
        txtStates.setText(letter);

    }

    public static boolean isNumber(String input) {
        try {
            Float.parseFloat(input);
            return true;
        } catch (Exception E) {
            return false;
        }


    }
}