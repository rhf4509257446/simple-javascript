package edu.citytech.cst.s23420931.Customer;

import com.google.gson.Gson;
import com.jbbwebsolutions.http.utility.JSONGet;
import edu.citytech.cst.s23420931.abccounter._MasterController;
import edu.citytech.cst.s23420931.model.CustomerPurchases;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

public class CustomerPurchaseController extends _MasterController implements Initializable {

    @FXML
    private TableView<CustomerPurchases> tvCustomerPurchase;
    @FXML
    private AnchorPane apYear;
    @FXML
    private AnchorPane apDays;
    @FXML
    private Button btSearch;
    @FXML
    private Label lblMessage;



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
    }

    public void search(final String url) {


        Map map = JSONGet.submitGet(url, Map.class);
        var data = (List) map.get("row.data");

        if (data ==null || data.size() == 0){
            lblMessage.setText("NO data was found for: " + lblMessage.getText());
            return;
        }

        ObservableList<CustomerPurchases> cp = tvCustomerPurchase.getItems();
        CustomerPurchases customer = new CustomerPurchases();
        customer.setCustomerId("abc-100");


        final Gson gson = new Gson();
        List<CustomerPurchases> customerPurchases = new ArrayList<>();
        for (Object row : data) {
            var model = gson.fromJson(row.toString(), CustomerPurchases.class);
            customerPurchases.add(model);
        }


        cp.addAll(customerPurchases);

    }
    @FXML
    void search(ActionEvent event) {

        final String sUrl="http://localhost:9215/api/reports/:year/1,2,3,4,5,6,7,8,9,10,11,12/:days/100,200/A,B,C,D";
               var children = apYear.getChildren();

               tvCustomerPurchase.refresh();

               tvCustomerPurchase.getItems().clear();

              List<String> list = new ArrayList<>();
               for (Node child :children){
                   if(child instanceof CheckBox){
                       var current = (CheckBox)child;
                       if(current.isSelected()){
                           list.add(current.getText());
                       }
                   }

               }
        String queryforYears = String.join(",", list);
        var url=sUrl.replace(":year", queryforYears);

      //logic for days
        children = apDays.getChildren();
        list.clear();
        for (Node child :children){
            if(child instanceof CheckBox){
                var current = (CheckBox)child;
                if(current.isSelected()){
                    list.add(current.getUserData().toString());
                }
            }

        }
        var queryforDays = String.join(",", list);
        url=url.replace(":days", queryforDays);

        lblMessage.setText(url);
        search(url);


    }

}
