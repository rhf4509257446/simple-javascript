package edu.citytech.cst.s23420931.Customer;

import com.jbbwebsolutions.http.utility.JSONGet;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.Map;

public class PieChartExperiments extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("My First JavaFX App");

        String url="http://localhost:9215/api/summary/year/2012";


        System.out.println(url);
        Map o = JSONGet.submitGet(url, Map.class);

        System.out.println(o);
        for (char c = 'A'; c <= 'D'; ++c) {
            var key = "row.count.code." + c;
            var data=o.get(key);
            System.out.println(data);
        }

        PieChart pieChart = new PieChart();

        PieChart.Data slice1 = new PieChart.Data("Desktop", 213);
        PieChart.Data slice2 = new PieChart.Data("Phone"  , 67);
        PieChart.Data slice3 = new PieChart.Data("Tablet" , 36);

        pieChart.getData().add(slice1);
        pieChart.getData().add(slice2);
        pieChart.getData().add(slice3);

        pieChart.setMinHeight(600);
        pieChart.setMinWidth(600);

        VBox vbox = new VBox(pieChart);

        Scene scene = new Scene(vbox, 750, 750);

        primaryStage.setScene(scene);

        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}